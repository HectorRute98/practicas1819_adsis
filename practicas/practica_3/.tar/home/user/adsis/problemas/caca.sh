#!/bin/bash
hola=heyy
echo "$hola" | read linea
echo es $linea

