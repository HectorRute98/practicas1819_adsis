#!/bin/bash

final_cadena=",como estas?"
for i in hola mundo
do
	echo "${i}${final_cadena}"
done
