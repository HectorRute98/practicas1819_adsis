#!/bin/bash
#Autor: Diego Marco
#Fecha:27/02/2019

echo "hola mundo!"
