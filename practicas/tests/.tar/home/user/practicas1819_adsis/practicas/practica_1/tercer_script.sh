#!/bin/bash

for i in $(ls)
do
	cat "${i}" 
done
