#!/bin/bash
for file in $(ls -R)
do echo $file
done
